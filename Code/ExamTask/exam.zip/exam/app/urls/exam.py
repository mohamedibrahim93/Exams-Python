from django.conf.urls import url
from ..Views import exam as views


urlpatterns= [
    url(r'^$', views.index, name='index'),
    url(r'^create$', views.create, name='create'),
    url(r'^generate$', views.generate, name='generate'),
    url(r'^addquestions/(?P<id>\d+)$', views.assign, name='addquestions'),
    url(r'^getquestions/(?P<id>\d+)$', views.getquestions, name='getquestions'),
    url(r'^getexamquestions/(?P<id>\d+)$', views.getexamquestions, name='getexamquestions'),
    url(r'^designexam/(?P<id>\d+)$', views.designexam, name='designexam'),
    url(r'^remvefromexam/(?P<id>\d+)/(?P<eid>\d+)$', views.remvefromexam, name='remvefromexam'),
    url(r'^addtoexam/(?P<id>\d+)/(?P<eid>\d+)$', views.addtoexam, name='addtoexam'),
    url(r'^printexam/(?P<id>\d+)$', views.printexam, name='printexam'),
    url(r'^getexams/(?P<id>\d+)$', views.getexams, name='getexams'),
    url(r'^edit/(?P<id>\d+)$', views.edit, name='edit'),
    url(r'^edit/update/(?P<id>\d+)$', views.update, name='update'),
    url(r'^delete/(?P<id>\d+)$', views.delete, name='delete'),

]